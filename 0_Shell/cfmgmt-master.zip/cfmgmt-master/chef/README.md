# Chef Provisioning Example

For more information check: [Configuration Management 101: Writing Chef Recipes](https://www.digitalocean.com/community/tutorials/configuration-management-101-writing-chef-recipes)
