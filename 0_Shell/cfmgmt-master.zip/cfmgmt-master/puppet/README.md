# Puppet Provisioning Example

For more information, check: [Configuration Management 101: Writing Puppet Manifests](https://www.digitalocean.com/community/tutorial_series/getting-started-with-configuration-management)
