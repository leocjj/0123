int func0 ( int var )
{
	if( 1 )
		return( 1 ) ;
	else if( 1 )
		return( 1 ) ;
	switch(var)
	{
	case 0 :
	default :
		break ;
	}
	for( ;1; )
		return( 1 ) ;
	while( 1 )
		return( 1 ) ;
	do{
		return( 1 ) ;
	}while( 1 ) ;
}

int func1 ( int var ,__attribute__ ((unused)) int test )
{
	int t ;

	t=sizeof ( var ) ;
	return( t ) ;
}
