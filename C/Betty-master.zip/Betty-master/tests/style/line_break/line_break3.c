int (*get_op_func(char *s))(int, int)
{
	char key[] = {'+', '-', '*', '/', '%'};
	int i = 0;
	int (*f[])(int, int) = {op_add, op_sub, op_mul, op_div, op_mod};

	while (i < 5)
	{
		return (0);
	}
	return (0);
}

int (*get_op_func(char *s))(int, int)
{
	char key[] = {'+', '-', '*', '/', '%'};
	int i = 0;
	int (*f[5])(int, int);

	while (i < 5)
	{
		return (0);
	}
	return (0);
}

int (*get_op_func(char *s))(int, int)
{
	char key[] = {'+', '-', '*', '/', '%'};
	int i = 0;
	int (*f[5])(int, int) = {op_add, op_sub, op_mul, op_div, op_mod};

	while (i < 5)
	{
		return (0);
	}
	return (0);
}
