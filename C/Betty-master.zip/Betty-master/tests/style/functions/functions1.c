int func0(void)
{
	return (1);
}

int func1(void)
{
	return (1);
}

int func2(void)
{
	return (1);
}

int func3(void)
{
	return (1);
}

int func4(void)
{
	return (1);
}

int func5(void)
{
	return (1);
}
