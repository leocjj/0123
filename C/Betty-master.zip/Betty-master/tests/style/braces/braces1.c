int func0(void)
{
	if (1)
	{
		func0();
		return (1);
	}
	else if (2)
	{
		func0();
		return (2);
	}
	else
	{
		func0();
		return (0);
	}
	while (1)
	{
		func0();
		return (1);
	}
	for (; 1;)
	{
		func0();
		return (1);
	}
	do {
		func0();
		return (1);
	} while (1);
}
